<p>User successfully saved!</p>
<p>Visable <a href="?Controller=users&action=display&id=<?php echo $user->id; ?>">here</a></p>