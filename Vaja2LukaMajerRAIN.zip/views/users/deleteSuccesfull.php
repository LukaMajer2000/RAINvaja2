<p>User successfully deleted!</p>
<a href="?Controller=users&action=index"><button>Back</button></a>