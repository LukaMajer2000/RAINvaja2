<p>All usesers have been deleted.</p>
<p><a href="?Controller=uporabniki&action=index">Back</a></p>
